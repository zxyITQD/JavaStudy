package com.xiaoyan.study;

public enum EnumDemo {
    INSTANCE;
    public static EnumDemo getInstance(){
        return INSTANCE;
    }
}
